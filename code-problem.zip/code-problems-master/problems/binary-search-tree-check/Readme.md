# Binary Search Tree Check

Given a binary tree, check whether it’s a binary search tree or not.

## Source

[http://www.ardendertat.com/2011/10/10/programming-interview-questions-7-binary-search-tree-check/](http://www.ardendertat.com/2011/10/10/programming-interview-questions-7-binary-search-tree-check/)
