# Prime Number

Write a function that accepts a number and return a boolean based on whether it's a prime number.
