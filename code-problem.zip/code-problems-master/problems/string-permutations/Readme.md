# All Permutations of a String

Generate all permutations of a given string. (Note: also known as the generating anagrams problem).

## Source

[http://www.ardendertat.com/2011/10/28/programming-interview-questions-11-all-permutations-of-string/](http://www.ardendertat.com/2011/10/28/programming-interview-questions-11-all-permutations-of-string/)
