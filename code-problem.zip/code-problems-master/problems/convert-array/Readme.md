# Convert Array

Given an array `[a1, a2, ..., aN, b1, b2, ..., bN, c1, c2, ..., cN]`  convert it to `[a1, b1, c1, a2, b2, c2, ..., aN, bN, cN]` in-place using constant extra space.

## Source

[http://www.ardendertat.com/2011/10/18/programming-interview-questions-9-convert-array/](http://www.ardendertat.com/2011/10/18/programming-interview-questions-9-convert-array/)
