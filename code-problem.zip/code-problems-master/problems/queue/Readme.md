# Basic Queue

Implement a basic queue function with the ability to `add` and `remove` values.
