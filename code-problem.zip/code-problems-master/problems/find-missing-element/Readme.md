# Find Missing Element

There is an array of non-negative integers. A second array is formed by shuffling the elements of the first array and deleting a random element. Given these two arrays, find which element is missing in the second array.

## Source

[http://www.ardendertat.com/2011/09/27/programming-interview-questions-4-find-missing-element/](http://www.ardendertat.com/2011/09/27/programming-interview-questions-4-find-missing-element/)
