# Integer Difference

Write a function that accepts an array of random integers and an integer *n*. Determine the number of times where two integers in the array have the difference of *n*.

```js
f(4, [1, 1, 5, 6, 9, 16, 27]) // 3 (Due to 2x [1, 5], and [5, 9])
f(2, [1, 1, 3, 3]) // 4 (Due to 4x [1, 3])
```
