# First Non-repeated character

Write a function that accepts a single string input and returns the first non-repeated character.

```js
"AABBC" // "C"
"AABBCCDEEFF" // "D"
```
