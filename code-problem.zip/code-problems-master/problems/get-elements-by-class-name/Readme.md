# Get Elements by Class Name

Implement the `getElementsByClassName(element, className)` function in Javascript.

## Source

[GlassDoor](http://www.glassdoor.com/Interview/Implement-the-getElementsByClassName-element-className-function-in-Javascript-QTN_226449.htm)
