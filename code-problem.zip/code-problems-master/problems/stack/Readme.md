# Basic Stack

Implement a basic stack function with the ability to `add` and `remove` values.
