# Merge Sort

Implement the [merge sort algorithm](http://en.wikipedia.org/wiki/Merge_sort).
