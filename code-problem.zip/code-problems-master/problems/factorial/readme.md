Factorial
==========

Factorial of any number n is defined as the multiplication of numbers from one to the given number. 

``
n! = 1 x 2 x 3 x 4 x ........ x n
``
