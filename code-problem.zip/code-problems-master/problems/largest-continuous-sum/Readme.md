# Largest Continuous Sum

Given an array of integers (positive and negative) find the largest continuous sum.

## Source

[http://www.ardendertat.com/2011/09/24/programming-interview-questions-3-largest-continuous-sum/](http://www.ardendertat.com/2011/09/24/programming-interview-questions-3-largest-continuous-sum/)
