# Find Even Occurring Element

Given an integer array, one element occurs even number of times and all others have odd occurrences. Find the element with even occurrences.

## Source

[http://www.ardendertat.com/2011/11/29/programming-interview-questions-18-find-even-occurring-element/](http://www.ardendertat.com/2011/11/29/programming-interview-questions-18-find-even-occurring-element/)
