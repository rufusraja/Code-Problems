# Missing Number

Write a function that accepts an array of integers in random order of unknown length, but with one number missing. Return the missing number.
