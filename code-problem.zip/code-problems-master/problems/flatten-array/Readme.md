# Flatten Array

Write a function that accepts a multi dimensional array and returns a flattened version.

```javascript
flatten([1, 2, [3, [4], 5, 6], 7]) // [1, 2, 3, 4, 5, 6, 7]
```
