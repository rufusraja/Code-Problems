# Room Number

You're in a hotel and you forgot what room number you were in but remember that the sum of it's divisors is greater than the number, yet there is no subset of those divisors that add up to the number itself. There are 100 rooms in the Hotel, what's your room number?

## Source

[Reddit](http://www.reddit.com/r/javascript/comments/1ftyjh/common_code_problems_solved_in_javascript_xpost/cae25ra)
