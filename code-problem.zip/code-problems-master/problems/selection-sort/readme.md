# Selection Sort

Implement the [selection sort algorithm](http://en.wikipedia.org/wiki/Selection_sort).
