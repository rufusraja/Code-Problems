# Quick Sort

Implement the [quick sort algorithm](http://en.wikipedia.org/wiki/Quicksort).
