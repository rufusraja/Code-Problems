# Linked List

Write a linked list implementation, better yet - make it doubly linked.
