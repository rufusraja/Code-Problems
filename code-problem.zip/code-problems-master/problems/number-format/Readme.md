# Numeric String

Format any number into a string with "," (commas) in the correct places. E.g. "1,000,000".
