# Money Formatting

Given an amount of money as a float, format it as a string.

```javascript
formatMoney(2310000.159897); // '2 310 000.16'
formatMoney(1600); // '1 600.00'
```
