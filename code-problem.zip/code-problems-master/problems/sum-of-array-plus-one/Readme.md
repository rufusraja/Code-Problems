# Sum of Array Plus One

Write a function that takes an array of integers and returns the sum of the integers after adding 1 to each.

```
plusOneSum([1, 2, 3, 4]); // 14
```
