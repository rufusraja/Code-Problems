# Binary Search Tree

Gives methods to create a binary search tree.

## Source

[http://en.wikipedia.org/wiki/Binary_search_tree](http://en.wikipedia.org/wiki/Binary_search_tree)
