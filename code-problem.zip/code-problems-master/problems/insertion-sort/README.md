# Insertion Sort

Implement the [insertion sort algorithm](http://en.wikipedia.org/wiki/Insertion_sort).
