# Longest Common Prefix

Given a String array, find the longest common prefix.

## Example

```
f([‘rocket’, ‘rockstar’, ‘rockbottom’, ‘rock’, ‘rollingstone’] // ‘ro’
f([‘shuffle’, ‘shuttle’, ‘shut’] // ‘shu’
```

## Source
Personal Phone Interview
