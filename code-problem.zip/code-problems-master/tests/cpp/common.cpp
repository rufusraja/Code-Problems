#include "common.hpp"

std::deque<std::tuple<int, Event>> eventLog;
int nextId;
