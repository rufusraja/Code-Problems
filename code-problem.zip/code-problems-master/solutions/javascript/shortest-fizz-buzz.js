for(i=0;++i<101;)console.log((i%3?'':'Fizz')+(i%5?'':'Buzz')||i)
