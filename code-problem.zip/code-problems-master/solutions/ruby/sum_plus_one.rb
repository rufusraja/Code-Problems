def sum_plus_one(array)
  array.reduce(&:+) + array.size
end
