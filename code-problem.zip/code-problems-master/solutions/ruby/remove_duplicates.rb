def remove_duplicates(str)
  str.split("").uniq.join
end
