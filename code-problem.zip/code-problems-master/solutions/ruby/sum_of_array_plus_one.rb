def sum_of_array_plus_one array
  array.inject(:+) + array.count
end
