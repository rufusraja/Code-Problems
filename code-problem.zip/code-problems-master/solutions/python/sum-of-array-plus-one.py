def plusOneSum(arr):
	"""returns the sum of the integers after adding 1 to each element"""
	return sum(arr)+len(arr)