<?php

function IntegerLength ($num) {
  return strlen((string) $num);
}

?>
