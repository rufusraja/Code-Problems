
/**
 * Returns the number of digits in the integer n
 */
int getNumberOfDigits(int n);

