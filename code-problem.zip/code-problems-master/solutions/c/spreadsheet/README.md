# Dependencies

This program depends on the following:  
1. pcre2-10.20 - Pattern matching, regular expression  
2. cmocka-1.0.0 - For Unit Tests  
  
Please refer to their respective documentations on how to install these libraries into your respective system

# Execution
It is required that the $LD\_LIBRARY\_PATH environment variable be set to the directory where the pcre.so is located if it is located other than /usr/lib 


